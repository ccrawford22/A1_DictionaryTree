//CS480 - Spring 2023
//Cody Crawford
//RedID:824167663
//Program 1
